#include <BasicLinearAlgebra.h>

class Robot : public MECOtron {
  private:
    path = 

  public:
    // Constructor
    Path() { }

    void control();

    // General functions
    bool init();  // Set up the robot

    bool controlEnabled();

    void button0callback();
    void button1callback();

    void push_position_stack

};

#endif // ROBOT_H
