#include <memory_pointer.h>

uint16_t MemoryPointer::_address = 0;
