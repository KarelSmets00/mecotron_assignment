these measurements were made with following values:
	Phat = 0.01
	initial distance = 15 cm
	step input to 20 cm
	xhat init = 0.15


values: Q1e-8_R0.000000095199_K300